-- MySQL dump 10.13  Distrib 8.0.22, for macos10.15 (x86_64)
--
-- Host: localhost    Database: campusbooks
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `OrderItem`
--

DROP TABLE IF EXISTS `OrderItem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OrderItem` (
  `idOrderLine` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `unitPrice` float NOT NULL,
  `quantity` int NOT NULL,
  `subtotal` float NOT NULL,
  `refOrder` int DEFAULT NULL,
  PRIMARY KEY (`idOrderLine`),
  KEY `idx-orderItem-refOrder` (`refOrder`),
  CONSTRAINT `fk-orderItem-refOrder` FOREIGN KEY (`refOrder`) REFERENCES `Order` (`idOrder`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrderItem`
--

LOCK TABLES `OrderItem` WRITE;
/*!40000 ALTER TABLE `OrderItem` DISABLE KEYS */;
INSERT INTO `OrderItem` VALUES (1,'Prima di dire addio (Nora Cooper Vol. 1)','Nwr53VFvpr6yMRJRD_FK17bIjf40jkmD.jpeg','Quando suo marito Joe, responsabile della squadra detective della polizia di Boston, viene freddato senza un apparente motivo durante una rapina in banca, la vita di Nora Cooper sembra andare in pezzi. Ma quel lutto diventa ancora più difficile da affrontare quando Nora scopre che prima di morire, senza dirle niente, il suo Joe ha venduto il cottage che da poco avevano acquistato insieme nella splendida isola di Martha’s Vineyard.\r\nTormentata dai dubbi e incapace di credere che l’uomo con cui ha trascorso più di trent’anni di vita possa aver tramato alle sue spalle, nascondendole non solo la verità, ma anche i soldi ricavati dalla vendita della casa, Nora non si rassegna. Si ritrova così a scavare in un torbido passato e a rischiare la sua stessa vita per cercare la verità.\r\nNel frattempo uno strano messaggio, che solo Joe potrebbe averle scritto, all’improvviso ribalta ogni possibile confine tra ciò che è reale e ciò che non lo è…\r\n\r\nUn giallo avvincente, ma soprattutto una storia di suspense e di sentimenti, che segna il debutto come investigatrice “sui generis” di Nora Cooper.',5.5,6,33,1),(2,'Libro','0jya5oYCDyJEFJkphNm46EtIkYqqyDih.jpeg','Marcello Macchia è nato all\'ospedale di Vasto nel 1978, partorito da sua mamma.\r\nMaccio Capatonda invece è nato nel 2004 dentro un armadio, quando Marcello, intento a registrare la voce fuori campo per il trailer La febbra, diede un nome al suo personaggio, senza pensarci troppo.\r\nNessuno dei due poteva immaginare che, da allora, non si sarebbero più separati, e insieme avrebbero creato sketch, trailer, serie tv e film che li avrebbero consacrati tra i protagonisti della scena comica italiana.\r\nIn questo libro Marcello Macchia e Maccio Capatonda si alternano per raccontare la loro storia, dai primi istanti di vita del primo a quello che sta facendo ora (proprio adesso!) il secondo. Un\'autobiografia sincera e profonda in cui il lettore, dopo aver finito di leggere i lunghi preamboli che precedono l\'inizio del libro, scopre le passioni segrete di Marcello e come ha fatto a diventare famoso Maccio, come sono nate le produzioni più famose e come ha fatto l\'autore a sopravvivere alla tragica, lenta scomparsa dei capelli.\r\nMa attenzione: grazie alla narrazione ironica e a tratti surreale, la storia talvolta prende derive imprevedibili venendo interrotta da aneddoti paradossali, dettagli improbabili, capitoli fuori dal tempo che si insinuano tra riflessioni serissime e rivelazioni a cuore aperto.\r\nInfine, Libro soddisferà alcuni grandi interrogativi che i fan di Marcello/Maccio si sono sempre posti: chi è Riccardino Fuffolo? Come è nato il tormentone di Padre Maronno? E soprattutto... Che fine ha fatto Buonanima?',9.99,10,99.9,2);
/*!40000 ALTER TABLE `OrderItem` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-06 16:32:58
