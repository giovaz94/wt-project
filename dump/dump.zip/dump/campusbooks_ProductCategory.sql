-- MySQL dump 10.13  Distrib 8.0.22, for macos10.15 (x86_64)
--
-- Host: localhost    Database: campusbooks
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ProductCategory`
--

DROP TABLE IF EXISTS `ProductCategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ProductCategory` (
  `idProductCategory` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`idProductCategory`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProductCategory`
--

LOCK TABLES `ProductCategory` WRITE;
/*!40000 ALTER TABLE `ProductCategory` DISABLE KEYS */;
INSERT INTO `ProductCategory` VALUES (1,'ROMANZO STORICO','Nel romanzo storico, invece, le vicende sono inserite in un contesto storico ben preciso e dettagliato, a cui ci si deve attenere rigorosamente, ma i personaggi e la trama che li muove possono essere liberamente creati dallo scrittore (stando però attento che risultino verosimili rispetto al contesto).'),(2,'BIOGRAFIA E AUTOBIOGRAFIA','Si tratta di generi in cui il nucleo del romanzo è rappresentato dalla vita del protagonista, nel primo caso raccontata da una terza persona, nel secondo dal protagonista stesso. In questo genere non c’è spazio per la fantasia, e l’estro creativo dello scrittore si deve limitare allo stile di scrittura.'),(3,'GIALLO, NOIR O HARD BOILED','Il termine “giallo” usato per definire questo genere è diffuso solo in Italia e deriva dal colore giallo delle copertine della fortunata collana di polizieschi lanciata da Mondadori nel 1929. La trama ruota intorno a un crimine e alle indagini che portano alla soluzione del caso.'),(4,'THRILLER','I libri che appartengono a questo genere sono quelli che tengono sempre il lettore con il fiato sospeso, in uno stato costante di tensione, creata appositamente tramite i procedimenti narrativi del climax e della suspense.'),(5,'AVVENTURA E AZIONE','Come dice già il nome, l’elemento centrale di questo genere è l’azione. La trama si sviluppa intorno a una missione da compiere, spesso in località esotiche o lontane, che mette alla prova le capacità di sopravvivenza del protagonista.'),(6,'FANTASCIENZA','I romanzi che appartengono a questo genere hanno come elemento centrale una tecnologia, reale o fittizia, con un forte impatto sulla vita dell’uomo. Spesso l’ambientazione è futuristica, ma può anche rappresentare un presente alternativo.'),(7,'DISTOPIA','Il genere distopico è la rappresentazione di una realtà alternativa rispetto a quella attuale, dalla quale però prende spunto per portare all’estremo alcune tendenze politiche o sociali considerate negativamente. La distopia è il contrario dell’utopia.'),(8,'FANTASY','In questo genere letterario a prevalere sono gli elementi fantastici, non spiegabili razionalmente. L’ambientazione è anch’essa frutto della più fervida immaginazione dell’autore e spesso rappresenta dei paesaggi naturali popolati da figure mitologiche o fantastiche, come elfi, fate, streghe, o addirittura inventate dall’autore, come gli hobbit.'),(9,'HORROR','I romanzi horror sfruttano le paure innate dei lettori per creare una trama terrifica, macabra e coinvolgente. L’ambientazione è necessariamente tenebrosa, buia e claustrofobica.'),(10,'YOUNG ADULT','Si tratta di un genere piuttosto nuovo, o almeno lo è la sua definizione. È dedicato a un pubblico giovane e tratta tematiche come l’amicizia, le relazioni affettive e familiari.'),(11,'ROMANZO DI FORMAZIONE','I romanzi di questo genere raccontano la maturazione del protagonista verso l’età adulta. Oggi molto spesso la narrazione è incentrata sugli stati d’animo del ragazzo o della ragazza, prediligendo una narrazione più psicologico-intimistica.'),(12,'ROSA O ROMANCE','L’elemento centrale della trama è una storia d’amore, rigorosamente a lieto fine. È un genere spesso bistrattato, ma è forse quello che più spesso “presta” alcuni dei suoi elementi agli altri: una bella storia d’amore è sempre gradita al lettore, qualunque libro stia leggendo!'),(13,'UMORISTICO','In testi di questo genere lo scrittore ha come scopo quello di far ridere il lettore, spesso attraverso la parodia della realtà o la sua enfasi.'),(14,'DIZIONARIO','Dizionari'),(15,'DIDATTICO','Libri scolastici');
/*!40000 ALTER TABLE `ProductCategory` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-06 16:32:58
